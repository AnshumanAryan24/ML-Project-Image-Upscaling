import io
import numpy as np
import cv2
import tensorflow as tf
from tensorflow.keras.models import load_model
from flask import Flask, request, send_file, render_template, jsonify
from flask_cors import CORS

# Ensure any custom layers used in the saved model are imported/registered
try:
    from custom_layers import PixelShuffle
    CUSTOM_OBJS = {"PixelShuffle": PixelShuffle}
except Exception:
    CUSTOM_OBJS = {}

app = Flask(__name__)
CORS(app)

# Constants
SCALE = 2
PATCH_SIZE = 128
STRIDE = 96
OVERLAP = PATCH_SIZE - STRIDE
PAD = OVERLAP // 2
MODEL_PATH = "SRGAN_generator_final(1).keras"


# ----------------------------
# Helper utilities
# ----------------------------
def extract_tiles_from_padded(padded_img, patch_size=PATCH_SIZE, stride=STRIDE):
    _, Hp, Wp, _ = padded_img.shape
    tiles = []
    starts = []

    y_positions = list(range(0, Hp - patch_size + 1, stride))
    x_positions = list(range(0, Wp - patch_size + 1, stride))

    # ensure edge coverage
    if len(y_positions) == 0 or (y_positions[-1] + patch_size) < Hp:
        last_y = max(0, Hp - patch_size)
        if len(y_positions) == 0 or y_positions[-1] != last_y:
            y_positions.append(last_y)

    if len(x_positions) == 0 or (x_positions[-1] + patch_size) < Wp:
        last_x = max(0, Wp - patch_size)
        if len(x_positions) == 0 or x_positions[-1] != last_x:
            x_positions.append(last_x)

    for y in y_positions:
        for x in x_positions:
            tile = padded_img[:, y:y + patch_size, x:x + patch_size, :]
            tiles.append(tile)
            starts.append((int(y), int(x)))

    return tiles, starts, Hp, Wp


def make_separable_weight(patch_out, overlap_out):
    if overlap_out <= 0:
        w = np.ones((patch_out,), dtype=np.float32)
    else:
        ramp = np.linspace(0.0, 1.0, overlap_out, endpoint=False, dtype=np.float32)
        w = np.ones((patch_out,), dtype=np.float32)
        w[:overlap_out] = ramp
        w[-overlap_out:] = ramp[::-1]
    return np.outer(w, w).astype(np.float32)


def stitch_tiles(up_tiles, starts, Hp, Wp, scale=SCALE,
                 patch_size=PATCH_SIZE, stride=STRIDE,
                 overlap=OVERLAP, pad=PAD):
    patch_out = patch_size * scale
    overlap_out = overlap * scale
    out_h = Hp * scale
    out_w = Wp * scale
    C = up_tiles[0].shape[-1]

    acc = np.zeros((out_h, out_w, C), dtype=np.float32)
    weight_acc = np.zeros((out_h, out_w, 1), dtype=np.float32)
    w2d = make_separable_weight(patch_out, overlap_out)

    for tile, (y, x) in zip(up_tiles, starts):
        y0, x0 = int(y) * scale, int(x) * scale
        y1, x1 = y0 + patch_out, x0 + patch_out
        tile_np = tile[0].astype(np.float32)

        if y1 > out_h or x1 > out_w:
            y1, x1 = min(y1, out_h), min(x1, out_w)
            tile_h, tile_w = y1 - y0, x1 - x0
            tile_np = tile_np[:tile_h, :tile_w, :]
            w_slice = w2d[:tile_h, :tile_w]
            acc[y0:y1, x0:x1, :] += tile_np * w_slice[..., None]
            weight_acc[y0:y1, x0:x1, 0] += w_slice
        else:
            acc[y0:y1, x0:x1, :] += tile_np * w2d[..., None]
            weight_acc[y0:y1, x0:x1, 0] += w2d

    weight_acc = np.maximum(weight_acc, 1e-6)
    final_padded = acc / weight_acc

    # crop padding safely
    top = pad * scale
    left = pad * scale
    bottom = final_padded.shape[0] - pad * scale
    right = final_padded.shape[1] - pad * scale
    final = final_padded[top:bottom, left:right, :]

    expected_h = (Hp - 2 * pad) * scale
    expected_w = (Wp - 2 * pad) * scale
    final = final[:expected_h, :expected_w, :]
    return np.clip(final, 0.0, 1.0)


def upscale_image_with_tiling(lr_image, generator_model, passes=2):
    """
    Runs the SR generator model multiple times to upscale progressively.
    Each pass doubles the resolution (2x).
    """
    img = lr_image.astype(np.float32)
    if img.ndim == 3:
        img_batch = np.expand_dims(img, 0)
    else:
        img_batch = img

    current_img = img_batch
    for i in range(passes):
        print(f"[Pass {i+1}] Input shape: {current_img.shape[1:]}")

        # --- Pad and extract tiles ---
        padded = tf.pad(current_img, [[0,0], [PAD,PAD], [PAD,PAD], [0,0]], mode='REFLECT')
        tiles, starts, Hp, Wp = extract_tiles_from_padded(padded, PATCH_SIZE, STRIDE)

        # --- Super-resolve each tile ---
        up_tiles = []
        for t in tiles:
            t = tf.cast(t, tf.float32)
            out = generator_model(t, training=False).numpy()
            up_tiles.append(out)

        # --- Stitch tiles together ---
        final = stitch_tiles(up_tiles, starts, Hp, Wp, scale=SCALE,
                             patch_size=PATCH_SIZE, stride=STRIDE, overlap=OVERLAP, pad=PAD)

        # Prepare for next pass
        current_img = np.expand_dims(final, 0)
        print(f"[Pass {i+1}] Output shape: {final.shape}")

    return final




print(f"[*] Loading model from {MODEL_PATH}...")
try:
    GENERATOR_MODEL = load_model(MODEL_PATH, compile=False, custom_objects=CUSTOM_OBJS)
    print("[*] Model loaded successfully.")
except Exception as e:
    print(f"[!] Error loading model: {e}")
    GENERATOR_MODEL = None

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/enhance', methods=['POST'])
def enhance_image():
    if GENERATOR_MODEL is None:
        return jsonify({"error": "Model is not loaded, cannot process image."}), 500

    if 'image' not in request.files:
        return jsonify({"error": "No image file provided."}), 400

    file = request.files['image']
    in_memory_file = io.BytesIO()
    file.save(in_memory_file)
    data = np.frombuffer(in_memory_file.getvalue(), dtype=np.uint8)
    img_bgr = cv2.imdecode(data, cv2.IMREAD_COLOR)

    if img_bgr is None:
        return jsonify({"error": "Could not decode image."}), 400

    img_rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
    lr_image = img_rgb.astype(np.float32) / 255.0

    try:
        # 🔥 Double-pass upscale (no interpolation, no black edges)
        sr_pass1 = upscale_image_with_tiling(lr_image, GENERATOR_MODEL)
        sr_image_normalized = sr_pass1
    except Exception as e:
        return jsonify({"error": f"Upscaling failed: {e}"}), 500

    sr_image_uint8 = (sr_image_normalized * 255.0).round().clip(0, 255).astype(np.uint8)
    sr_image_bgr = cv2.cvtColor(sr_image_uint8, cv2.COLOR_RGB2BGR)

    is_success, buffer = cv2.imencode(".png", sr_image_bgr)
    if not is_success:
        return jsonify({"error": "Failed to encode enhanced image."}), 500

    return send_file(io.BytesIO(buffer), mimetype='image/png', as_attachment=False)


if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000)
